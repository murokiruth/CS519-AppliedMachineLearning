Project Title: HW6: Compare Clustering Methods
Author: Sonnie Owallah
Date: 04/03/2025

Description:
This report analyzes the application of K-means and Hierarchical clustering algorithms, on the Iris and MNIST datasets. The performance of these models was evaluated based on sum of squared errors (SSE) / inertia, silhouette score, adjusted rand index (ARI) and execution time

System and Software Requirements:
1. Python version 3.10 or higher.
2. Scikit-learn library
3. SciPy library
4. Matplotlib library
5. NumPy
 

Files Included:
1. A zip file named hw6_sonnieowallah which has the following files.
2. readme.txt - a file with detailed instructions on how to run the Python program.
3. index.py: The Python script to execute the program.
4. report.pdf

Steps to Run the Program:
1. Ensure you have Python 3.10 or higher. You can do this by opening your command prompt/terminal and running  python --version. If you do not have Python or need to update the version, visit the official Python website at https://www.python.org/downloads/.
2. Install the SciPy library from the command prompt/terminal using  pip install SciPy.
3. Install the Scikit-learn library from the command prompt/terminal using  pip install scikit-learn.
4. Install the Matplotlib library from the command prompt/terminal using  pip install matplotlib.
5. Install the NumPy library from the command prompt/terminal using  pip install numpy.
6. Extract the files in the zip file and save them in an unzipped directory/folder.
7. Ensure that all the files are in the same directory.
8. To run the program from the command prompt/ terminal, open your command prompt/ terminal and navigate to the directory containing the files.
9. Execute the following commands:    python index.py


Expected Output:
1. Text output
* Data shape
* Sum of Squared Errors (SSE) / Inertia 
* Silhouette score 
* Adjusted Rand Index (ARI) 
* Execution Time

2. Generated plots 
* elbow method & silhouette analysis plots
* silhouette plots
* dendrogram plots

Troubleshooting: 
- If the script fails to execute, ensure the Python version is 3.10 or higher, the required packages are installed, and verify the path for the dataset is correct.
 
